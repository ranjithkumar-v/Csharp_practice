﻿using System;
namespace Question2;
    class Program{
        public static void Main(string[] args)
        {
            System.Console.Write("count: ");
            int count = Convert.ToInt32(Console.ReadLine());
            int i =1;
            int sum = 0;
            while(i<=count){
                
                sum += i*i;
                i++;


            }
            System.Console.WriteLine("sum: " + sum);
        }
    }

            