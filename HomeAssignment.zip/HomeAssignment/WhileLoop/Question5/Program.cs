﻿using System.Runtime.InteropServices;
using System;
namespace Question5;
    class Program{
        public static void Main(string[] args)
        {

            System.Console.Write("enter a number: ");
            int count = Convert.ToInt32(Console.ReadLine());
            int i =1;
            int sum =0;
            int num ;
            while(i<=count){
                System.Console.Write("Enter a number: ");
                num = Convert.ToInt32(Console.ReadLine());
                sum += num;
                i++;

            }
            System.Console.WriteLine("sum of the given number: "+sum);
        }
    }


            