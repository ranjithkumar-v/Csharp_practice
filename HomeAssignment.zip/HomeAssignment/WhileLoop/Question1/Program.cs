﻿using System;
namespace Question1;
    class Program{
        public static void Main(string[] args)
        {
            int i=1;
           while (i<=10)
           {
            System.Console.Write(i + " ");
            i++;
            
           }
        }
    }

            
