﻿using System;
namespace Question4;
    class Program{
        public static void Main(string[] args)
        {
        System.Console.Write("Enter a number: ");
        bool flag;
        int num ;
        string n = Console.ReadLine();
        flag = int.TryParse(n, out num);
        while(!flag){

            System.Console.WriteLine("Invalid input enter again");
            n = Console.ReadLine();
           flag = int.TryParse(n, out num);
           }
        System.Console.WriteLine("valid input " + num);
        }
    }