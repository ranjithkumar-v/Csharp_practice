﻿using System;
namespace Question3;   
class Program
    {
        public static void Main(string[] args)
        {
            char[]  chars= new char[] {'c','a','f','b','k','h','z','t','m','p','l','d'};
            
            AscendingOrder(chars);
            DescendingOrder(chars);
        }   
    public static void AscendingOrder(char[] number)
     {
        Console.WriteLine("\n Bubble Sorted Array Elements in ascending order  :");

        for(int i=0;i<number.Length-1;i++)
        { 
            int  flag=0;
            for(int j=0;j<number.Length-1-i;j++)
            {
                if(number[j] > number[j+1])
                {
                    char temp = number[j];
                    number[j] = number[j+1];
                    number[j+1] = temp;
                    flag=1;
                }
            }
            if(flag == 0)
            {
                break;
            }
        }
        foreach(char elements in number)
        {
            System.Console.Write(elements + " ");
        }
     }
     
       public  static void DescendingOrder(char [] number)
        { 
                Console.WriteLine("\n Bubble Sorted Array Elements in descending order  :");

                for(int i =number.Length-1;i>=0;i--)
                {
                    System.Console.Write(number[i] + " ");
                }
        }

         
     }
