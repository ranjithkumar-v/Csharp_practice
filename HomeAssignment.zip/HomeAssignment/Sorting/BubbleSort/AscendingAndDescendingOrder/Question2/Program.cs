﻿using System;
namespace Question2;   
class Program
    {
        public static void Main(string[] args)
        {
            string [] input = new string [] {"SF3023", "SF3021", "SF3067", "SF3043", "SF3053", "SF3032", "SF3063", "SF3089", "SF3062", "SF3092"};
            Console.WriteLine("\nSorted Array Elements :");
            int [] finalarr = new int[10];
            int k=0;
            foreach(string str in input)
            {
                finalarr[k] = Convert.ToInt32(str.Replace("SF",""));
                k++;
            }
            AscendingOrder(finalarr);
            DescendingOrder(finalarr);
            

           
         
     }
      public static void AscendingOrder(int []finalarr)
     {
        Console.WriteLine("\nSorted Array Elements in ascending order  :");

        for(int i=0;i<finalarr.Length-1;i++)
        { 
            int  flag=0;
            for(int j=0;j<finalarr.Length-1-i;j++)
            {
                if(finalarr[j] > finalarr[j+1])
                {
                    int temp = finalarr[j];
                    finalarr[j] = finalarr[j+1];
                    finalarr[j+1] = temp;
                    flag=1;
                }
            }
            if(flag == 0){
                break;
            }
        }
        foreach(int elements in finalarr){
            System.Console.Write($"SF{elements} ");
        }
     }
     
       public  static void DescendingOrder(int [] finalarr)
        { 
                Console.WriteLine("\nSorted Array Elements in descending order  :");

                for(int i =finalarr.Length-1;i>=0;i--)
                {
                    System.Console.Write($"SF{finalarr[i]}  ");
                }
        }
}