﻿using System;
namespace Question1;   
class Program
    {
        public static void Main(string[] args)
        {
            double [] number = new double[] {1.1,65.3,93.9,55.5,3.5,6.9};
            AscendingOrder(number);
            DescendingOrder(number);
         
       }
     public static void AscendingOrder(double [] number)
     {
        Console.WriteLine("\nSorted Array Elements in ascending order  :");

        for(int i=0;i<number.Length-1;i++)
        { 
            int  flag=0;
            for(int j=0;j<number.Length-1-i;j++)
            {
                if(number[j] > number[j+1])
                {
                    double temp = number[j];
                    number[j] = number[j+1];
                    number[j+1] = temp;
                    flag=1;
                }
            }
            if(flag == 0){
                break;
            }
        }
        foreach(double elements in number){
            System.Console.Write(elements + " ");
        }
     }
     
       public  static void DescendingOrder(double [] number)
        { 
                Console.WriteLine("\nSorted Array Elements in descending order  :");

                for(int  i =number.Length-1;i>=0;i--)
                {
                    System.Console.Write(number[i] + " ");
                }
        }

}