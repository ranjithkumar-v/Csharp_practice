﻿using System;
namespace Question1;   
class Program
    {
        public static void Main(string[] args)
        {
            double[] number = new double[] {1.1,65.3,93.9,55.5,3.5,6.9};
            AscendingOrder(number);
            DescendingOrder(number);
         
       }
     public static void AscendingOrder(double [] number)
     {
        Console.WriteLine("\nSelection Sorted Array Elements in ascending order  :");

        for(int i=0;i<number.Length-1;i++)
        {
              int min = i;
            for(int j=i+1;j<number.Length;j++)
            {
                if(number[j] < number[min]){
                    min =j;
                }

            }
            if(min !=i){
                double temp = number[i];
                number[i] = number[min];
                number[min] = temp;
            }
        }
       
        foreach(double elements in number){
            System.Console.Write(elements + " ");
        }
     }
     
       public  static void DescendingOrder(double [] number)
        { 
                Console.WriteLine("\nSelection Sorted Array Elements in descending order  :");

                for(int i =number.Length-1;i>=0;i--)
                {
                    System.Console.Write(number[i] + " ");
                }
        }

}