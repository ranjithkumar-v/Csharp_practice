﻿using System;
namespace Question1;   
class Program
    {
        public static void Main(string[] args)
        {
            char[] chars = new char[] {'c','a','f','b','k','h','z','t','m','p','l','d'};
            AscendingOrder(chars);
            DescendingOrder(chars);
         
       }
     public static void AscendingOrder(char [] chars)
     {
        Console.WriteLine("\nSelection Sorted Array Elements in ascending order  :");

        for(int i=0;i<chars.Length-1;i++)
        {
            int min = i;
            for(int j=i+1;j<chars.Length;j++)
            {
                if(chars[j] < chars[min]){
                    min =j;
                }

            }
            if(min !=i){
                char temp = chars[i];
                chars[i] = chars[min];
                chars[min] = temp;
            }
        }
       
        foreach(char elements in chars){
            System.Console.Write(elements + " ");
        }
     }
     
       public  static void DescendingOrder(char [] chars)
        { 
                Console.WriteLine("\nSelection Sorted Array Elements in descending order  :");

                for(int i =chars.Length-1;i>=0;i--)
                {
                    System.Console.Write(chars[i] + " ");
                }
        }

}