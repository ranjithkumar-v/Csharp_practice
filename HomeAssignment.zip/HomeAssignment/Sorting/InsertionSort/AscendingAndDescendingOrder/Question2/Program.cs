﻿using System;
namespace Question2;   
class Program
    {
        public static void Main(string[] args)
        {
            string [] input = new string [] {"SF3023", "SF3021", "SF3067", "SF3043", "SF3053", "SF3032", "SF3063", "SF3089", "SF3062", "SF3092"};
            Console.WriteLine("\nInsertion sorted Array Elements :");
            int [] finalarr = new int[10];
            int k=0;
            foreach(string str in input){
                finalarr[k] = Convert.ToInt32(str.Replace("SF",""));
                k++;
            }
            for (int i = 1; i <finalarr.Length; i++)
            {
                int temp = finalarr[i];
                int j;
                for(j=i-1;j>=0 && finalarr[j] > temp;j--)
                {
                        finalarr[j+1] = finalarr[j];

                }
                finalarr[j+1] = temp;
                
            }
       
        foreach( int elements in finalarr)
        {
            System.Console.Write($" SF{elements} ");
        }
        
        Console.WriteLine("\n insertion Sorted Array Elements in descending order  :");

                for(int i =finalarr.Length-1;i>=0;i--)
                {
                    System.Console.Write($"SF{finalarr[i]}  ");
                }
         
     }
}