﻿using System;
namespace Question1;   
class Program
    {
        public static void Main(string[] args)
        {
            int[] number = new int[] {45,33,12,55,77,22,33,14,67,12,35};
            AscendingOrder(number);
            DescendingOrder(number); 
           
           
         
     }
     public static void AscendingOrder(int [] number)
     {
        Console.WriteLine("\nSorted Array Elements in ascending order  :");

         for (int i = 1; i <number.Length; i++)
            {
                int temp = number[i];
                int j;
                for(j=i-1;j>=0 && number[j] >temp;j--)
                {
                        number[j+1] = number[j];

                }
                number[j+1] = temp;
                
            }
       
        foreach(int elements in number){
            System.Console.Write(elements + " ");
        }
     }

          public  static void DescendingOrder(int [] number)
        { 
                Console.WriteLine("\nSorted Array Elements in descending order  :");

                for(int i =number.Length-1;i>=0;i--)
                {
                    System.Console.Write(number[i] + " ");
                }
     }
}