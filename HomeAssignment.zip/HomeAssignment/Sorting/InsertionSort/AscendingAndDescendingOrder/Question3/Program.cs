﻿using System;
namespace Question3;   
class Program
    {
        public static void Main(string[] args)
        {
            char[]  chars= new char[] {'c','a','f','b','k','h','z','t','m','p','l','d'};
            Console.WriteLine("\n Insertion Sorted Array Elements  in ascending order:");
            for (int i = 1; i <chars.Length; i++)
            {
                char temp = chars[i];
                int j;
                for(j=i-1;j>=0 && chars[j] >temp;j--)
                {
                        chars[j+1] = chars[j];

                }
                chars[j+1] = temp;
                
            }
       
        foreach(char elements in chars){
            System.Console.Write(elements + " ");
        }

      Console.WriteLine("\n insertion Sorted Array Elements in descending order  :");

                for(int i =chars.Length-1;i>=0;i--)
                {
                    System.Console.Write(chars[i] + " ");
                }     
         
     }
}