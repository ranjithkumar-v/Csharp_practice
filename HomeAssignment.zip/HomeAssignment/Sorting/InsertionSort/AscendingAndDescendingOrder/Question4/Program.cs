﻿using System;
namespace Question4;   
class Program
    {
        public static void Main(string[] args)
        {
            double[] number = new double[] {1.1,65.3,93.9,55.5,3.5,6.9};
            AscendingOrder(number);
            DescendingOrder(number); 
           
           
         
     }
     public static void AscendingOrder(double [] number)
     {
        Console.WriteLine("\nSorted Array Elements in ascending order  :");

         for (int i = 1; i <number.Length; i++)
            {
                double temp = number[i];
                int  j;
                for(j=i-1;j>=0 && number[j] >temp;j--)
                {
                        number[j+1] = number[j];

                }
                number[j+1] = temp;
                
            }
       
        foreach(double elements in number){
            System.Console.Write(elements + " ");
        }
     }

          public  static void DescendingOrder(double [] number)
        { 
                Console.WriteLine("\nSorted Array Elements in descending order  :");

                for(int  i =number.Length-1;i>=0;i--)
                {
                    System.Console.Write(number[i] + " ");
                }
     }
}