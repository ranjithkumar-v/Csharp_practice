﻿using System;
namespace Question5;
class Program{
    public static void Main(string[] args)
    {
        System.Console.Write("physics: ");
        int physics = Convert.ToInt32(Console.ReadLine());
         System.Console.Write("chemistry: ");
        int chemistry = Convert.ToInt32(Console.ReadLine());
        System.Console.Write("Maths: ");
         int maths = Convert.ToInt32(Console.ReadLine());
         int total = physics + chemistry +maths;
         int percentage = total / 3;
         if(percentage >= 75){
            System.Console.WriteLine("the candidate is  eligible for admission.");
        
         }
         else{
                System.Console.WriteLine("the candidate is Not eligible for admission.");            
         }
       
       
    }
}
