﻿using System;
namespace Question8;
class Question8{
    public static void Main(string[] args)
    {   
        System.Console.WriteLine("enter sugar level in number ");
        int sugarLevel = Convert.ToInt32(Console.ReadLine());
        if(sugarLevel < 90){
            System.Console.WriteLine("Low sugar");
        }
       else if(sugarLevel >= 90 && sugarLevel <130){
            System.Console.WriteLine("Normal");
        }
       else if(sugarLevel >=130 && sugarLevel <140){
            System.Console.WriteLine("Medium");
        }
      else  if(sugarLevel >=140 && sugarLevel <=170){
            System.Console.WriteLine("try to reduce it from now");
        }
        else{
            System.Console.WriteLine("you are high  sugar patient ");
        }
    }
}