﻿using System;
namespace Question1;
class Program{
    public static void Main(string[] args)
{
    System.Console.Write("Test Data: ");

   int num = Convert.ToInt32(Console.ReadLine());
    if(num % 2 == 0)
    {
        System.Console.WriteLine(num + " is an Even number");
    }
    else{
        System.Console.WriteLine(num + " is an Odd number");
    }
}
}