﻿
using System.Dynamic;
using System;
namespace Question6{
    class Program{
public static void Main(string[] args)
    {
        System.Console.Write("Enter Temperature: ");
        int Temperature = Convert.ToInt32(Console.ReadLine());
        if(Temperature < 0){
            System.Console.WriteLine("freezing weather");
        
        }
        if(Temperature >=0 && Temperature <10){
            System.Console.WriteLine("very cold weather");
        
        }
        if(Temperature >= 10 && Temperature < 20){
            System.Console.WriteLine("cold weather ");
        }
        if(Temperature >=20 && Temperature <30){
            System.Console.WriteLine("normal");
        }
        if(Temperature >=30 && Temperature <=40){
            System.Console.WriteLine("its hot");
        }
        if(Temperature >=40){
            System.Console.WriteLine("very hot");
        }
    }
    }
    
}
