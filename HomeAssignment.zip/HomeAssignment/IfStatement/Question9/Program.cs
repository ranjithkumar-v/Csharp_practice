﻿using System;
namespace Question9{
    class Program{
        public static void Main(string[] args)
        {
            System.Console.WriteLine("Enter month ");
            string month = Console.ReadLine().ToLower();
            if(month =="december" || month == "january"  ||  month == "february" ){
                System.Console.WriteLine("Winter season");
            }
            if(month == "march" || month == "april" || month == "may"){
                System.Console.WriteLine("Spring season");
            }
            if(month == "june" || month == "july" || month == "august")
            {
                System.Console.WriteLine("Summer Season");
            }
            if(month == "september" || month =="october" || month == "november"){
                System.Console.WriteLine("rainfall season");
            }
        }

    }
}