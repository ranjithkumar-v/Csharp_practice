﻿using System;
namespace Question2;
class Program{
    public static void Main(string[] args)
    {
        Console.Write("Test Data ");
       int age = Convert.ToInt32 (Console.ReadLine());
       if(age >= 18)
       {
        System.Console.WriteLine("Congratulation!");
        System.Console.WriteLine("You are eligible for casting your vote.");
       }
       else
       {
        System.Console.WriteLine("Your not eligible ");
       }
    }
}