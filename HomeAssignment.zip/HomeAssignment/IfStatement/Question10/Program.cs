﻿using System;
namespace Question10;
class Program{
    public static void Main(string[] args)
    {
        string password = "Hiteam";
        System.Console.WriteLine("Enter a password");
       string userPassword = Console.ReadLine();
       if(password == userPassword){
        System.Console.WriteLine("Right password");
       }
    else{
        System.Console.WriteLine("wrong password");
    }
    }

}