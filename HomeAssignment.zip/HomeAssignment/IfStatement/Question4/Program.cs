﻿using System;
namespace Question4
{
    class Program{
        public static void Main(string[] args)
        {
            System.Console.Write("Enter firstnum = ");
            int firstNum = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("Enter secondnum = ");
            int secondNum = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("Enter thirdnum = ");
            int thirdNum = Convert.ToInt32(Console.ReadLine());
            if(firstNum > secondNum && firstNum > thirdNum){
                System.Console.WriteLine( " first number is the largest Number");
            
            }
            else if(secondNum > firstNum && secondNum > thirdNum ){

                System.Console.WriteLine( " second number is the largest Number");

            }
            else{
                System.Console.WriteLine( " third number is the largest Number");

            }


            
        }
    }
}