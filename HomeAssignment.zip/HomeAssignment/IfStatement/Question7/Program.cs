﻿using System;
namespace Question7;
class Program{
    public static void Main(string[] args)
    {
        System.Console.WriteLine("Enter a customerID");
        int customerID = Convert.ToInt32( Console.ReadLine());
        System.Console.WriteLine("ENter customer Name");
         string customerName =    Console.ReadLine();
         System.Console.WriteLine("enter units consumed ");
          int unitsConsumed  = Convert.ToInt32(Console.ReadLine());
          if(unitsConsumed >= 84){
            System.Console.WriteLine("Customer Id: " + customerID);
            System.Console.WriteLine("Customer Name: " + customerName);
            System.Console.WriteLine("unit consumed: " + unitsConsumed);
            System.Console.WriteLine("total amount:  100");
          }
          else if(unitsConsumed > 84 && unitsConsumed <=199)
          {
             System.Console.WriteLine("Customer Id: " + customerID);
            System.Console.WriteLine("Customer Name: " + customerName);
            System.Console.WriteLine("unit consumed: " + unitsConsumed);
            System.Console.WriteLine("amount: " + unitsConsumed * 1.20);
          }
           else if(unitsConsumed >=200 && unitsConsumed < 400)
          {
             System.Console.WriteLine("Customer Id: " + customerID);
            System.Console.WriteLine("Customer Name: " + customerName);
            System.Console.WriteLine("unit consumed: " + unitsConsumed);
            System.Console.WriteLine("amount: " + unitsConsumed * 1.50);
          }
           else if(unitsConsumed >=400  && unitsConsumed <600)
          {
             System.Console.WriteLine("Customer Id: " + customerID);
            System.Console.WriteLine("Customer Name: " + customerName);
            System.Console.WriteLine("unit consumed: " + unitsConsumed);
            System.Console.WriteLine("amount: " + unitsConsumed * 1.80);
            double surcharge;
            surcharge = surcharge * 1.5;
            System.Console.WriteLine("surcharge" +    );
          }


         
        
        
    }
}