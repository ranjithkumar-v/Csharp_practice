﻿using System;
namespace Question1;
class Program{
    public static void Main(string[] args)
    {
        int [] arr = new int[]{45,33,12,55,77,22,33,14,67,78,22,11,44,66,88,12,35,84,93,77};
        Array.Sort(arr);
        int mid,beg=0,end = arr.Length-1;
        System.Console.WriteLine("enter Search element");
        int searchElement = int.Parse(Console.ReadLine());
        bool flag =true;
        while(beg<=end)
        {
            mid = (beg+end)/2;
            if(arr[mid] == searchElement )
            {
                System.Console.WriteLine($" {searchElement} found at position {mid+1}");
                flag = false;
                break;
            }
            else{
                if(searchElement < arr[mid])
                {
                    end = mid -1;
                }
                else 
                {
                    beg = mid + 1; 
                }
            }
        }
        if(flag){
            System.Console.WriteLine("element not found");
        }
    }
}