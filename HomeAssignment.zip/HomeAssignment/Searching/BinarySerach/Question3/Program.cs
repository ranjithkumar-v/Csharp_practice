﻿using System;
namespace Question3;
class Program{
    public static void Main(string[] args)
    {
        char [] arr = new char[]{'c','a','f','b','k','h','j','I','i','z','t','m','p','l','d'};
        Array.Sort(arr);
        int mid,beg=0,end = arr.Length-1;
        System.Console.WriteLine("enter Search char");
        char searchElement = Convert.ToChar(Console.ReadLine().ToLower());
        bool flag =true;
        while(beg<=end)
        {
            mid = (beg+end)/2;
            if(arr[mid] == searchElement )
            {
                System.Console.WriteLine($" {searchElement} found at position {mid}");
                flag = false;
                break;
            }
            else{
                if(searchElement < arr[mid])
                {
                    end = mid -1;
                }
                else 
                {
                    beg = mid + 1; 
                }
            }
        }
        if(flag){
            System.Console.WriteLine("element not found");
        }
    }
}