﻿using System;
namespace Question2;
class Program{
    public static void Main(string[] args)
    {
        string [] arr = new string[]{"SF3023", "SF3021", "SF3067", "SF3043", "SF3053", "SF3032", "SF3063", "SF3089", "SF3062", "SF3092"};
        Array.Sort(arr);
        int [] finalArray = new int[arr.Length];
        for(int i =0;i<arr.Length;i++){
           finalArray[i] =Convert.ToInt32(arr[i].Replace("SF",""));
        }

        int mid,beg=0,end = arr.Length-1;
        System.Console.WriteLine("enter Search element in the Format SF(Your uniqueID)");
        string searchString = Console.ReadLine().ToUpper();
        int searchElement =Convert.ToInt32(searchString.Replace("SF",""));
        bool flag =true;
        while(beg<=end)
        {
            mid = (beg+end)/2;
            if(finalArray[mid] == searchElement )
            {
                System.Console.WriteLine($" SF{searchElement} found at position {mid+1}");
                flag = false;
                break;
            }
            else{
                if(searchElement < finalArray[mid])
                {
                    end = mid -1;
                }
                else 
                {
                    beg = mid + 1; 
                }
            }
        }
        if(flag){
            System.Console.WriteLine("element not found");
        }
    }
}