﻿using System;
namespace Question4;
class Program{
    public static void Main(string[] args)
    {
        double [] arr = new double[]{1.1,65.3,93.9,55.5,3.5,6.9 };
        Array.Sort(arr);
        int mid,beg=0,end = arr.Length-1;
        System.Console.WriteLine("enter Search element");
        double searchElement = double.Parse(Console.ReadLine());
        bool flag =true;
        while(beg<=end)
        {
            mid = (beg+end)/2;
            if(arr[mid] == searchElement )
            {
                System.Console.WriteLine($" {searchElement} found at position {mid+1}");
                flag = false;
                break;
            }
            else{
                if(searchElement < arr[mid])
                {
                    end = mid -1;
                }
                else 
                {
                    beg = mid + 1; 
                }
            }
        }
        if(flag){
            System.Console.WriteLine("element not found");
        }
    }
}