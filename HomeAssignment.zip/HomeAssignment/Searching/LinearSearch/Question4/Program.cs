﻿using System.Reflection.Metadata.Ecma335;
using System;
namespace Question4;
class Program{
    public static void Main(string[] args)
    {
        // System.Console.WriteLine("enter no of element");
        // int number = int.Parse(Console.ReadLine());
        double [] arr = new double[]{1.1,65.3,93.9,55.5,3.5,6.9};

        // for(int i=0;i<number;i++)
        // {
        //     arr[i] = Convert.ToInt32(Console.ReadLine());
        // }
        System.Console.WriteLine("enter search Element");
        double SearchElement = double.Parse(Console.ReadLine());
        bool flag = true;
        for(int i=0;i<arr.Length;i++)
        {
            if(arr[i] == SearchElement){
                flag= false;
                System.Console.WriteLine($"Element found at position {i+1}");
            }

        }
        if(flag)
        {
            System.Console.WriteLine("Element Not found ");
        }
    }
}