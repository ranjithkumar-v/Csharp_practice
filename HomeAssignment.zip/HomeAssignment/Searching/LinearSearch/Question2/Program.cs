﻿using System.Reflection.Metadata.Ecma335;
using System;
namespace Question2;
class Program{
    public static void Main(string[] args)
    {
        // System.Console.WriteLine("enter no of element");
        // int number = int.Parse(Console.ReadLine());
        string [] arr = new string[]{"SF3023", "SF3021", "SF3067", "SF3043", "SF3053", "SF3032", "SF3063", "SF3089", "SF3062", "SF3092"};

        // for(int i=0;i<number;i++)
        // {
        //     arr[i] = Convert.ToInt32(Console.ReadLine());
        // }
        System.Console.WriteLine("enter search string");
        string SearchElement = Console.ReadLine().ToUpper();
        bool flag = true;
        for(int i=0;i<arr.Length;i++)
        {
            if(arr[i] == SearchElement){
                flag= false;
                System.Console.WriteLine($"Element found at position {i+1}");
            }

        }
        if(flag)
        {
            System.Console.WriteLine("Element Not found ");
        }
    }
}