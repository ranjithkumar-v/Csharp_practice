﻿using System.Reflection.Metadata.Ecma335;
using System;
namespace Question1;
class Program{
    public static void Main(string[] args)
    {
        // System.Console.WriteLine("enter no of element");
        // int number = int.Parse(Console.ReadLine());
        int [] arr = new int[]{45,33,12,55,77,22,33,14,67,78,22,11,44,66,88,12,35,84,93,77};

        // for(int i=0;i<number;i++)
        // {
        //     arr[i] = Convert.ToInt32(Console.ReadLine());
        // }
        System.Console.WriteLine("enter search Element");
        int SearchElement = int.Parse(Console.ReadLine());
        bool flag = true;
        for(int i=0;i<arr.Length;i++)
        {
            if(arr[i] == SearchElement){
                flag= false;
                System.Console.WriteLine($"Element found at position {i+1}");
            }

        }
        if(flag)
        {
            System.Console.WriteLine("Element Not found ");
        }
    }
}