﻿using System.Reflection.Metadata.Ecma335;
using System;
namespace Question3;
class Program{
    public static void Main(string[] args)
    {
        // System.Console.WriteLine("enter no of element");
        // int number = int.Parse(Console.ReadLine());
        char [] arr = new char[]{'c','a','f','b','k','h','j','i','i','z','t','m','p','l','d' };

        // for(int i=0;i<number;i++)
        // {
        //     arr[i] = Convert.ToInt32(Console.ReadLine());
        // }
        System.Console.WriteLine("enter search Character");
        char SearchElement =Convert.ToChar (Console.ReadLine().ToLower());
        bool flag = true;
        for(int i=0;i<arr.Length;i++)
        {
            if(arr[i] == SearchElement){
                flag= false;
                System.Console.WriteLine($"Element found at position {i+1}");
            }

        }
        if(flag)
        {
            System.Console.WriteLine("Element Not found ");
        }
    }
}