﻿using System;
namespace Question;
class Program{
    public static void Main(string[] args)
    {
        string userName = "user";
        string passWord = "pass";
        System.Console.Write("enter username");
        string  name = Console.ReadLine();
        
        System.Console.Write("enter password");
        string userPass = Console.ReadLine();
        if(userName == name && userPass == passWord){
            System.Console.WriteLine("Password entered successfully!");
        }

        else{
            System.Console.WriteLine("wrong password");
        }
    }
}