﻿using System;
namespace Question7;
    class Program{
        public static void Main(string[] args)
        {    
            System.Console.Write("Enter a string ");
            string str = Console.ReadLine().ToLower();

            int vowels =0;
            int consontant = 0;
            int i;
           for( i =0;i<str.Length;i++)
           {
                if( str[i] == 'a' || str[i] == 'e' || str[i] == 'i' || str[i] == 'o' || str[i] == 'u' ){
                    vowels++;
                }
                if(str[i] >= 'a'&& str[i] <='z' ){
                    consontant++;
                }
            }
            System.Console.WriteLine("consontant "+ (consontant  - vowels));
            System.Console.WriteLine("vowels "+ vowels);
        }
    }
