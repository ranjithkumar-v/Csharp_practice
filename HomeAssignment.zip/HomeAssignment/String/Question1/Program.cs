﻿
using System;
namespace Question1;
    class Program{
        public static void Main(string[] args)
        {   System.Console.Write("enter the string ");
           string str= Console.ReadLine();
           int count =0;
           foreach(char ch in str){
            count++;
           }
           System.Console.WriteLine("length of the string " + count);

            
}
}