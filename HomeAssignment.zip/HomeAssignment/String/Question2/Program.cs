﻿using System;
namespace Question2{
    class Program{
        public static void Main(string[] args)
        {
            System.Console.WriteLine("enter a String ");
            string str = Console.ReadLine();
            System.Console.WriteLine("Character of string");
            foreach(char ch in str){
                System.Console.Write(ch+" ");
            }
        }
    }

}