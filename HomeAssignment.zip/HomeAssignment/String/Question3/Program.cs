﻿using System;
namespace Question3;
    class Program{
        public static void Main(string[] args)
        {
            System.Console.WriteLine("enter a String ");
            string str = Console.ReadLine();
            System.Console.WriteLine("reversed Character ");
            for(int i=str.Length - 1;i>=0;i--)
                System.Console.Write(str[i]+" ");
            }
        }
    

