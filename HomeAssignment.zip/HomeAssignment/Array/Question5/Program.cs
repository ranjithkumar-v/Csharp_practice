﻿using System;  
namespace  Question5;
class Program
{  
    public static void Main() 
 {
	int[] arr1 = new int[10];
	int[] arr2 = new int[10];
	int[] arr3 = new int[10];
    int number,i,j=0,k=0;	
	

       Console.Write("enter number of elements: ");
	   number = Convert.ToInt32(Console.ReadLine()); 	   
   
       Console.Write("Input {0} elements in the array :\n",number);
       for(i=0;i<number;i++)
            {
	      Console.Write("element - {0} : ",i);
    	  arr1[i] = Convert.ToInt32(Console.ReadLine()); 		  
	    }

    for(i=0;i<number;i++)
    {
	if (arr1[i]%2 == 0)
	{
	   arr2[j] = arr1[i];
	   j++;
	}
	else
	{
	   arr3[k] = arr1[i];
	   k++;
	}
    }

    Console.Write("\nThe Even elements are : \n");
    for(i=0;i<j;i++)
    {
	Console.Write("{0} ",arr2[i]);
    }

    Console.Write("\nThe Odd elements are :\n");
    for(i=0;i<k;i++)
    {
	Console.Write("{0} ", arr3[i]);
    }
    Console.Write("\n\n");	
   }	
 } 

