﻿using System;
namespace Question1;
    class Program{
        public static void Main(string[] args)
        {
        System.Console.WriteLine("enter no of element");
        int num = Convert.ToInt32(Console.ReadLine());
        int [] arr = new int[num];
        for(int i =0;i<arr.Length;i++){
            System.Console.Write("element - ");
            arr[i] =Convert.ToInt32(Console.ReadLine());
        }
         for(int i =0;i<arr.Length;i++){
            System.Console.Write(arr[i]+" ");
        }
}
}