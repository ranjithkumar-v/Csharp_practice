﻿using System.Threading.Tasks.Dataflow;
using System;
namespace Question7;
    class Program{
        public static void Main(string[] args)
        {
          int[,] arr = new int[3,3];
          int i,j;
          System.Console.WriteLine("enter array elements");
          for(i=0;i<3;i++)
          {
            for( j=0;j<3;j++)
            {
            Console.Write("element - [{0},{1}] : ",i,j);
            arr[i,j] = Convert.ToInt32(Console.ReadLine()); 


            }
          }
        Console.Write("\nThe matrix is : \n");
        for(i=0;i<3;i++)
        {
             Console.Write("\n");
            for(j=0;j<3;j++){
            Console.Write("{0}\t",arr[i,j]);
            }
           
     }
            Console.Write("\n\n");
          }
        }
    
   