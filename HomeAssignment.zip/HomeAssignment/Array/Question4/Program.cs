﻿using System;
namespace Question4;
class Program{
    public static void Main(string[] args)
    {
        System.Console.WriteLine("Enter the number of elements");
        int n = Convert.ToInt32(Console.ReadLine());
        int[] arr = new int[n];
        for(int i =0;i<n;i++){
            System.Console.Write("enter a number ");
            arr[i] = Convert.ToInt32(Console.ReadLine());

        }
        int max = arr[0];
        int min = arr[0];
        for(int i =1;i<n;i++){
            if(arr[i] > max){
                max = arr[i];
            }
        }
        for(int j=1;j<n;j++){
            if(arr[j] < min){
                min = arr[j];
            }
        }
        System.Console.WriteLine("maximum= "+ max+ " minimum = " + min);
    }
}