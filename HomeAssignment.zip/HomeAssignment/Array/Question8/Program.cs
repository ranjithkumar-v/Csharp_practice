﻿
using System;
namespace Question8;
class Program{
    public static void Main(string[] args)
    {
        System.Console.WriteLine("enter size of matrix ");
        int size = Convert.ToInt32(Console.ReadLine());
        int[,] arr1 = new int[size,size];
        int[,] arr2 = new int[size,size];
        System.Console.WriteLine("enter element for  first element");
        for(int i =0;i<size;i++)
        {
            for(int j=0;j<size;j++)
            {
                System.Console.WriteLine("element - " + i + " "+ j);
                arr1 [i,j]= Convert.ToInt32(Console.ReadLine());

            }
        }
        System.Console.WriteLine("enter element for ");
      for(int i =0;i<size;i++)
      {
            for(int j=0;j<size;j++)
            {
                System.Console.WriteLine("element - " + i + " "+ j);
                arr2[i,j]= Convert.ToInt32(Console.ReadLine());

            }
            
        }
        int [,] arr3 = new int[size,size];


        for(int i =0;i<size;i++){
            for(int j=0;j<size;j++){
            
                arr3[i,j] = arr1[i,j] + arr2[i,j];

            }
            
        }
        System.Console.WriteLine("addtion of matrix ");
        for(int i =0;i<size;i++)
        {
            for(int j=0;j<size;j++)
            {
            
                System.Console.Write(arr3[i,j]+ " ");
            }
            System.Console.WriteLine("\n");
            
        }

        
}
}