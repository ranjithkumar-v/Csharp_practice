﻿using System;
namespace Question5;
class Program{
    public static void Main(string[] args)
    {   int sum =0;
        System.Console.WriteLine("Enter a no of terms");
        int number = Convert.ToInt32(Console.ReadLine());
        System.Console.WriteLine("odd numbers are");
        for(int i=1;i<=number;i++ ){
            System.Console.WriteLine(2*i-1);
            sum += 2*i-1;
        }
        System.Console.WriteLine("sum of odd number are "+sum);
    }
}