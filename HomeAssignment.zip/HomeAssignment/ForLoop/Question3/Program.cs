﻿using System;
namespace Question3;
    class Program{
        public static void Main(string[] args)
        {

            Console.Write(" number of terms : ");
            int numOfTerm = Convert.ToInt32(Console.ReadLine());
            for(int i=1;i<=numOfTerm;i++){
                System.Console.WriteLine("Number is " + i + " Cube of the " + i + "is: " + (i*i*i));
            }
        }
    }
