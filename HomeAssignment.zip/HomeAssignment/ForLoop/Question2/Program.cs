﻿using System;
namespace Question2;
    class Program{
        public static void Main(string[] args)
        {
            double sum = 0;
            int num ;
            System.Console.Write("input ");
           for(int i = 1;i<=10;i++){
            num = Convert.ToInt32(Console.ReadLine());
            sum += num;
            
           }
           double average = sum / 10;
           System.Console.WriteLine("Sum: " + sum);
           System.Console.WriteLine("Average: " + average);
        }
    }
