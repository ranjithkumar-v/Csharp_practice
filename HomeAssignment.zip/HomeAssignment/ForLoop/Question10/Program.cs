﻿using System;
namespace Question10;
class Program 
   {  
     public static void Main(string[] args)  
      {  
          int number, i, m=0, flag=0;    
          Console.Write("Enter the Number  ");    
          number = int.Parse(Console.ReadLine());  
          m=number/2;    
          for(i = 2; i <= m; i++)    
          {    
           if(number % i == 0)    
            {    
             Console.Write(number +" is not Prime number.");    
             flag=1;    
             break;    
            }    
          }    
          if (flag==0)    
           Console.Write(number+" is Prime number.");       
     }  
   } 