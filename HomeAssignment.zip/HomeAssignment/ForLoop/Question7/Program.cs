﻿using System.ComponentModel.Design.Serialization;
using System;
namespace Question7;
    class Program
    {
        public static void Main(string[] args)
        {
            int row = 4;
            int space = row+4-1;
         for(int i =1;i<=row;i++)
         {
            for(int j=space;j>=1;j--)
            {
                System.Console.Write(" ");
            }
         
         for(int k=1;k<=i;k++)
         {
         System.Console.Write("* ");
         }
         System.Console.WriteLine("\n");
          space--;
       }
    }
    }