﻿using System;
namespace Question6;
class Program{
    public static void Main(string[] args)
    {
        System.Console.WriteLine("Enter a number");
        int number = Convert.ToInt32(Console.ReadLine());
       int factNumber =  factorial(number);
       System.Console.WriteLine("factorial of a number " + factNumber);
    
        int factorial(int n)
        {
            
        int i,fact=1;      
       for(i=1;i<=n;i++)
       {      
        fact=fact*i;      
       }      
      return fact;
             
        }
    }
}