﻿using System;  
namespace Question4;
 class Program 
   {  
     public static void Main(string[] args)  
      {  
         int n1=0,n2=1,n3,number;    
         Console.Write("Enter the number of elements: ");    
         number = int.Parse(Console.ReadLine());  
         Console.Write(n1+" "+n2+" ");  
        fibonacciSerires(number);
        void fibonacciSerires(int n){
            for(int i=2;i<n;++i)
         {    
          n3=n1+n2;    
          Console.Write(n3+" ");    
          n1=n2;    
          n2=n3;    
         } 
        }
            
      }  
   }  