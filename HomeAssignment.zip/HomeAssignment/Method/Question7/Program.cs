﻿using System;
namespace Question7;
class Program{
    public static void Main(string[] args)
    {

        System.Console.WriteLine("enter a string");
        string str = Console.ReadLine();
        palidrome(str);
        
        void  palidrome(string s){
            string rev ="";
                for (int i = s.Length-1; i >=0; i--) //String Reverse  
            {  
                rev += s[i].ToString();  
            }  
            if (rev == s) // Checking whether string is palindrome or not  
            {  
                Console.WriteLine(" Given String is Palindrome");  
            }  
            else  
            {  
                Console.WriteLine(" Given String is not Palindrome");  
            }  
        }  
            
        }
        
    }
