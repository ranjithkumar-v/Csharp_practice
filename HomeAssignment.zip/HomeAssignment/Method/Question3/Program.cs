﻿using System;
namespace Question3;
class Program{
    public static void Main(string[] args)
    {
        System.Console.WriteLine("enter a number: ");
        int num1 = Convert.ToInt32(Console.ReadLine());
        System.Console.WriteLine("enter a another number: ");
        int num2 = Convert.ToInt32(Console.ReadLine());
        
        Swap(num1,num2);
        void Swap(int a, int b){

            int temp;
            temp = a;
            a = b;
            b = temp;
            System.Console.WriteLine("after swapping: a = "+ a + " b = "+b );
        }
    }
}