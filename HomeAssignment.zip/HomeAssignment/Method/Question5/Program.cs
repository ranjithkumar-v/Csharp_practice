﻿using System;
namespace Question5;
class Program{
    public static void Main(string[] args)
    {
        System.Console.WriteLine("Enter a number");
        int num = Convert.ToInt32(Console.ReadLine());
        PrimeNumber(num);

      void PrimeNumber(int a ){
        int count = 0;
           for(int i = 1;i<=a;i++){
            if(a % i == 0  ){
                count++;

            }
           
           }
            if(count == 2 ){
                System.Console.WriteLine(a +" is prime number");
            }
            else{
                System.Console.WriteLine(a + " not is a prime number");
            }
      }
        
    
    }
}
