﻿using System;
namespace Question2;
class Program{
    public static void Main(string[] args)
    {
        Message();
     void Message(){
        System.Console.WriteLine("welcome friends");
        System.Console.WriteLine("have a nice day");
     }
    }
}