﻿using System.Globalization;
using System;
namespace Question7;
class Program{
    public static void Main(string[] args)
    {
       int sum  = GetDetails();
       int percantage = sum /3;
       System.Console.WriteLine("percentage: " + percantage);
       int GetDetails()
       {
        System.Console.WriteLine("mark 1 : ");
        int a = Convert.ToInt32(Console.ReadLine());
        System.Console.WriteLine("mark 2 : ");
        int b = Convert.ToInt32(Console.ReadLine());

        System.Console.WriteLine("mark 3 : ");
            int c = Convert.ToInt32(Console.ReadLine());
        return a+b+c;


       }
    }
}
    