﻿
using System.ComponentModel.DataAnnotations.Schema;
using System;
namespace Question1;
class Program {
    public static void Main(string[] args)
    {
        System.Console.WriteLine("Enter a first number");
        int num1 = Convert.ToInt32 (Console.ReadLine());
        
        System.Console.WriteLine("ener a second number");
        int num2 =    Convert.ToInt32(Console.ReadLine());
        int add = Addition(num1,num2);
        System.Console.WriteLine("Addition: "+ add);
        int sub = Substraction(num1,num2);
        System.Console.WriteLine("substraction: "+sub);        
        int mul = Multiplication(num1,num2);
        System.Console.WriteLine("multiplication: "+ mul);
        int div = Division(num1,num2);
        System.Console.WriteLine("division: "+ div);        int Addition(int a,int b){
        return a+b;
        }

        int Substraction(int a,int b){
            return a-b;
        }

         int Multiplication(int a,int b){
        return a*b;
        }
        int Division(int a,int b){
        return a/b;
        }
    }
}

