﻿using System;
namespace Question10{
    class Program{
        public static void Main(string[] args)
        {   
            Console.Write("value1  = ");
            int value1 =Convert.ToInt32(Console.ReadLine());
            Console.Write("value2 = ");
            int value2 =Convert.ToInt32(Console.ReadLine());

            if (value1 > value2) {
                Console.WriteLine("True");
            }
            else{
                Console.WriteLine("False");
            }
            if(value1 < value2){
                
                Console.WriteLine("True");

            }
            else{
                Console.WriteLine("False");

            }
            if(value1 >= value2){
                Console.WriteLine("True");
                }
            else{
                Console.WriteLine("False");

            }
            if(value1 == value2){
                Console.WriteLine("True");

            }
            else{
                Console.WriteLine("False");
                }

            if(value1 != value2){
                Console.WriteLine("True");
             }
             else{
                Console.WriteLine("False");

             }
             if(value1 <= value2){
                Console.WriteLine("True");

             }
             else{
                Console.WriteLine("False");

             }
             if(value1 >=10 && value2 >= 10){
                    Console.WriteLine("True");

             }
             else{
                Console.WriteLine("False");

             }
        

            if(value1 >=10 || value2 >= 30){
                Console.WriteLine("True");

            }
            else{
                    Console.WriteLine("False");

            }
            if(!(value1 >20)){
                    Console.WriteLine("True");

            }
            else{
                Console.WriteLine("False");

            }
            string value;
            if(value1 == 15){
                    value = "True";
                    Console.WriteLine(value);
 
            }
            else{
                value = "False";
                Console.WriteLine("False");

            }
            Console.WriteLine(value1++);
            Console.WriteLine(value1--);
        }
    }
}
