﻿using System;
namespace Question1{

    class Program{
        public static void Main(string[] args)
        {   Console.Write("Enter name ");
            string name = Console.ReadLine();
            //Concatenation
            Console.WriteLine("Hello: " + name);
            //Place  Holder
            Console.WriteLine("Hello: {0}",name);
            //Interpolation
            Console.WriteLine($"Hello: {name}");
        }
    }
}

