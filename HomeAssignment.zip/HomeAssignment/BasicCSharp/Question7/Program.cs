﻿using System;
namespace Question7{
    class Program{
        public static void Main(string[] args)
        {
            Console.Write("a = " );
        long a = Convert.ToInt64(Console.ReadLine());
        Console.Write("b = " );
        long b = Convert.ToInt64(Console.ReadLine());
        long output = (a * a) + 2 * (a*b) + b * b;
        Console.WriteLine("output = "+ output);


        }
    }
}