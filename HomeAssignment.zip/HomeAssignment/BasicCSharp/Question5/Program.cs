﻿using System;
namespace Question5{
    class Program{
        public static void Main(string[] args)
        {
            Console.Write("physics = ");

            int physics = Convert.ToInt32(Console.ReadLine());
            Console.Write("chemistry = ");
            int chemistry = Convert.ToInt32(Console.ReadLine());
            Console.Write("maths = ");
            int maths = Convert.ToInt32(Console.ReadLine());
            int sum = physics + chemistry + maths;
            Console.WriteLine("sum = "+ sum);
            int percantage  = sum / 3;
            Console.WriteLine("percentage = " + percantage);


        }
    }
}

