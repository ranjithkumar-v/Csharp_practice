﻿using System;
namespace Question3{
    class Program{
        public static void Main(string[] args)
        {
            Console.Write("Enter the amount of Celsius ");
            int  celsius = Convert.ToInt32(Console.ReadLine());
            double kelvin = celsius+273.15;
            double fahrenheit =(celsius * 9/5) + 32;
            Console.WriteLine("Kelvin = " + kelvin);
            Console.WriteLine("fahrenheit = " + fahrenheit );

        }
    }
}
