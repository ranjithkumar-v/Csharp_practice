﻿using System;
namespace Question8{
    class Program{
        public static void Main(string[] args)
        {
            Console.Write("Meter = ");
            double  meter = Convert.ToDouble(Console.ReadLine());
            double cm = meter * 100;
            double  mm  = cm * 10;
            double inch  = 39.3 * meter;
            double foot =  12 * meter;
            double mile = 0.0006213715277778 * meter;
            Console.WriteLine("CM = " + cm);
            Console.WriteLine("MM = " + mm);
            Console.WriteLine("Inch = " + inch);
            Console.WriteLine("Foot  = " + foot );
            Console.WriteLine("mile = " + mile);


        }
    }
}