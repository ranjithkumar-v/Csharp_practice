﻿
using System;
namespace Question4{
    class Program{
        public static void Main(string[] args)
        {
            Console.Write("Radius = ");
            double radius = Convert.ToDouble(Console.ReadLine());
            Console.Write("Height = ");
            double height = Convert.ToDouble(Console.ReadLine());
            double volume = 3.14 * radius * radius * height;
            Console.WriteLine("volume = " + volume );

        }
    }
}