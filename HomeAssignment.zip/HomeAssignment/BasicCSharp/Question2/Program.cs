﻿using System;
namespace Question2{
    class Program{
        public static void Main(string[] args)
        {
            Console.Write("Input the first number: ");
            string firstNum =  Console.ReadLine();
            int   firstN = Convert.ToInt32(firstNum);               
            Console.Write("Input the Second number: ");
            string secondNum = Console.ReadLine();
            int secondN = Convert.ToInt32(secondNum);
            int add =  firstN + secondN;
            int sub = firstN - secondN;
            int mul = firstN * secondN;
            int div = firstN / secondN;
            int modulo =firstN  % secondN;
            Console.WriteLine("Add " + add);
            Console.WriteLine("Sub "+ sub);
            Console.WriteLine("mul "+firstN * secondN);
            Console.WriteLine("div "+ div);
            Console.WriteLine("modulo div "+ modulo);







        }
    }
}
