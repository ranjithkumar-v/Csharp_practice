﻿
using System;
namespace Question9{
    class Program{
        public static void Main(string[] args)
        {
            Console.Write("Input speed = ");
            int speed = Convert.ToInt32(Console.ReadLine());
            Console.Write("Time  = ");
             int seconds = Convert.ToInt32(Console.ReadLine());
             int distance = speed * seconds * 5/18;
             Console.WriteLine("output = " + distance);
           

        }
    }
}