﻿using System.Globalization;
using System.Security.AccessControl;
using System;
namespace Question6;
class Program{
    public static void Main(string[] args)
    {
        DateTime date = DateTime.ParseExact(Console.ReadLine(),"MM/dd/yyyy hh:mm:ss tt",null);
        DateTime newDate = date.AddDays(40);
        System.Console.WriteLine("day of the week after 40 days " + newDate.DayOfWeek );
    }
}
