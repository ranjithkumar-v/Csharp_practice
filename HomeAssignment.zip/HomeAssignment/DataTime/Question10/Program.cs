﻿using System;
namespace Question10;
    class Program{
        public static void Main(string[] args)
        {   System.Console.WriteLine("enter date");
            DateTime date = DateTime.ParseExact(Console.ReadLine(),"dd/MM/yyyy",null);
            DateTime tomorrow = date.AddDays(1);
            DateTime yesterday = date.AddDays(-1);
            System.Console.WriteLine("Tomorrow: "+ tomorrow.ToString("dd/MM/yyyy"));
            System.Console.WriteLine("Today: " + yesterday.ToString("dd/MM/yyyy"));

            
        }
  
}