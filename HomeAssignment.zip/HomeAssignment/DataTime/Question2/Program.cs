﻿using System.Net;
using System;
namespace Question2;
    class Program{
        public static void Main(string[] args)
        {
         DateTime date = new DateTime(2022,04,29,11,49,00);
         System.Console.WriteLine(date.ToString());
         System.Console.WriteLine(date.ToShortDateString());
         System.Console.WriteLine(date.ToLongDateString());
         System.Console.WriteLine(date.ToString("dd/MM/yyyy hh:mm:ss tt"));
         System.Console.WriteLine(date.ToString("dd/MM/2022"));
          System.Console.WriteLine(date.ToString("hh:mm:ss tt"));

}
}
