﻿using System;
namespace Question3;
class Program{
    public static void Main(string[] args)
    {
        DateTime date = DateTime.ParseExact(Console.ReadLine(),"dd/MM/yyyy hh:mm:ss tt",null);
        System.Console.WriteLine(date.Year);
        System.Console.WriteLine(date.Month);
        System.Console.WriteLine(date.Day);
        System.Console.WriteLine(date.Hour);
        System.Console.WriteLine(date.Minute);
        System.Console.WriteLine(date.Second);

        
        

    }
}
