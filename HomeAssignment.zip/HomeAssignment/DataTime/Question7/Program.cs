﻿using System;
namespace Question7;
    class Program{
        public static void Main(string[] args)
        {
            System.Console.WriteLine("enter a two dates");
        DateTime date1 = DateTime.ParseExact(Console.ReadLine(),"MM/dd/yyyy",null);
        DateTime date2 = DateTime.ParseExact(Console.ReadLine(),"MM/dd/yyyy",null);
        if(date1 < date2){
                    System.Console.WriteLine(date2+" is eariler than  " + date1);

        }
        else{
            System.Console.WriteLine(date1 +" is later than  " + date2);
        }


                
}
    }
