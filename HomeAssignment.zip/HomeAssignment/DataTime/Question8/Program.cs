﻿using System;
namespace Question8;
    class Program{
        public static void Main(string[] args)
        {   System.Console.WriteLine("enter the date ");
            DateTime date = DateTime.ParseExact(Console.ReadLine(),"MM/dd/yyyy",null);
            DateTime previousYear = date.AddYears(-1);
            DateTime futureYear = date.AddYears(1);
            System.Console.WriteLine("previousYear " + previousYear.ToString("dd/MM/yyyy"));
            System.Console.WriteLine("futureYear " + futureYear.ToString("dd/MM/yyyy"));
            }
}
