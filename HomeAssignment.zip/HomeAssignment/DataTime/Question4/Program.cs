﻿
using System;
namespace Question4;
    class Program{
        public static void Main(string[] args)
        {
            DateTime date  = new DateTime(2016,11,07);
            System.Console.WriteLine("the day of week for "+ date.ToString("dd/MM/yyyy")+" "+date.DayOfWeek);


}
}