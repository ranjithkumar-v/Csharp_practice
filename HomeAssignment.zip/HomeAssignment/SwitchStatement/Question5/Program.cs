﻿
using System;
namespace Question1;
    class Program{
        public static void Main(string[] args)
        {

            Console.Write("enter the country name ");
            string countryName = Convert.ToString(Console.ReadLine().ToLower());

            

 switch(countryName){
               
			  case "india":
                    System.Console.WriteLine("1. Gambir \n 2. Ashwin \n 3.Dhoni \n 4. Jadeja");
                    break;
                case "pakistan":
                    System.Console.WriteLine("1.bakar");
                    break;
                 case "bangalesh":
                    System.Console.WriteLine("1.mithun");
                    break;
             default:
				System.Console.WriteLine("Invalid option");
				break;

		}
        }
    }
