﻿using System;
namespace Question6;
    class Program{
        public static void Main(string[] args)
        {
            System.Console.WriteLine("enter radius: ");
            double r = Convert.ToDouble(Console.ReadLine());
            System.Console.WriteLine("ENTER  a choice");
            int choice = Convert.ToInt32(Console.ReadLine());
            switch(choice){
                case 1:
                     System.Console.WriteLine("Area = " +  3.14 * (r * r) );
                    break;
                case 2:
                    System.Console.WriteLine("Perimeter = " + (2 * 3.14) * r);
                    break;
                case 3:
                    System.Console.WriteLine("Diameter = " + (2* r));
                    break;
                default:
                    System.Console.WriteLine("invalid choice ");
                    break;

            }
           
        }           
}