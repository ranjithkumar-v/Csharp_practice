﻿using System;
namespace SwitchAssignment;
class Program {
    public static void Main(string[] args)
    {   System.Console.Write("Enter firstnum: ");
        int firstNum = Convert.ToInt32(Console.ReadLine()) ;
        System.Console.Write("Enter secondnum: ");
        int secondNum = Convert.ToInt32(Console.ReadLine()) ;
        
        System.Console.WriteLine("Select any operation \n 1. addition  \n 2. substraction \n 3. multiplication \n 4. division \n 5.exit");
        int  option = Convert.ToInt32(Console.ReadLine());
        switch(option){

            case 1:
                    System.Console.WriteLine("addition: " + (firstNum + secondNum)) ;
                    break;
            case 2:
                System.Console.WriteLine("substraction: " + (firstNum - secondNum));
                break;
            case 3:
                System.Console.WriteLine("Multiplication: " + firstNum * secondNum);
                break;
            case 4:
                System.Console.WriteLine("Division: " + firstNum / secondNum );
                break;
            case 5:
                break;

            default:
                System.Console.WriteLine("Invalid operation");
                break;
                
        }
        
    }
}
