using System.Security.Cryptography.X509Certificates;
using Microsoft.Win32.SafeHandles;
namespace Question1
{
    public abstract class Library
    {
        public int s_serialNumber = 1000;

        public abstract string SerialNumber{get;set;}
        public abstract string AuthorName{get;set;}
        public abstract string BookName{get;set;}
        public abstract string PublisherName{get;set;}
        public abstract int Year{get;set;}

        public abstract void SetBookInfo(string authorName,string bookName,string publisherName,int year);
        public abstract void DisplayInfo();

    }
}