﻿using System;
namespace Question1;
class Program
{
    public static void Main(string[] args)
    {
        CSEDepartment cse = new CSEDepartment();
        cse.SetBookInfo("Ranjith","Beginning","kumar",2022);
        cse.DisplayInfo();
        EEEDepartment eee = new EEEDepartment();
        eee.SetBookInfo("Ram","End","kumar",2021);
        eee.DisplayInfo();
    }
}