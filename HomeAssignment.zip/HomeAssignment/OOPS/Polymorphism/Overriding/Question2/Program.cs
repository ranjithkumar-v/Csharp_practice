﻿using System;
namespace Question2;
class Program
{
    public static void Main(string[] args)
    {
            Syncfusion sync = new Syncfusion("chennai",28,"Software Developer","Ranjith","Venkatesan","male","B.E");
            sync.CalculateSalary();
            sync.Display();
    }
}