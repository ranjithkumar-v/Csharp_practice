using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question2
{
    public class FreeLancer:PersonDetails
    {
            public String Role { get; set; }
            public int SalaryAmount { get; set; }
            public int NoOfWorking { get; set; }

            public FreeLancer(string name,string fatherName,string gender,string qualification):base(name,fatherName,gender,qualification)
            {

            }
            public virtual void CalculateSalary()
            {
                SalaryAmount = NoOfWorking * 500;
            }
            public virtual void Display()
            {
                Console.Write($"\nEmployee Name: {Name}");
                Console.WriteLine($"\nQualification : {Qualification}");
                Console.WriteLine($"\nRole {Role}");
                Console.Write($"\n Worked days {NoOfWorking}");
                Console.Write($"\nSalary {SalaryAmount}");
            }
}
}