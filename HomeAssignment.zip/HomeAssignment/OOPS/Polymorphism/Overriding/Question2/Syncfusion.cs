using System.Data;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question2
{
    public class Syncfusion:FreeLancer
    {
        private static int s_employeeID =100;

        public string EmployeeID { get; set; }
        public string WorkLocation{get;set;}

       public Syncfusion (string workLocation,int noOfWorking,string role,string name,string fatherName,string gender,string qualification)
       {
            s_employeeID++;
            EmployeeID ="SF"+ s_employeeID;
            WorkLocation = workLocation;
            NoOfWorking = noOfWorking;
            Role = role;


       }
        public override void CalculateSalary()
        {
            base.CalculateSalary();
        }
        public override void Display()
        {
            base.Display();
        }
    }
}