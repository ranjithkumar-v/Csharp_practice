using System;
namespace Question1
{
    public class EmployeeInfo:PersonInfo
    {
        private static int s_employeeID=1000;
        public  string EmployeeID{get;set;}

        public override  void Display()
        {
            System.Console.WriteLine($"Name: {Name} FatherName {FatherName} Mobile Number {MobileNumber} gender {Gender}");
        }
        public EmployeeInfo(string name,string fatherName,string mobileNumber, string gender):base(name,fatherName,mobileNumber,gender){
            s_employeeID++;
            EmployeeID = "EID" +s_employeeID;
        }

    }
}