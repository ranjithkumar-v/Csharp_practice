using System;
namespace Question1
{
    public class SalaryInfo:EmployeeInfo
    {
        public int  NumberofDaysWorked{get;set;}
        public override void Display(){
          System.Console.WriteLine($"Salary {NumberofDaysWorked * 500} ");
        }
    public SalaryInfo(int numberOfWorked,string name,string fatherName,string mobileNumber, string gender):base(name,fatherName,mobileNumber,gender){
        NumberofDaysWorked = numberOfWorked;
    }
    }
}