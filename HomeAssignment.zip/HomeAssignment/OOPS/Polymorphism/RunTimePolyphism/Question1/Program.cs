﻿using System;
namespace Question1;
class Program{
    public static void Main(string[] args)
    {
        PersonInfo person;
        EmployeeInfo employee = new EmployeeInfo("Ranjith","venkatesan","2394127","male");
        person = employee;
        person.Display();
        SalaryInfo salary = new SalaryInfo(5,"Ranjith","venkatesan","2394127","male");
        person = salary;
        person.Display();


    }
}