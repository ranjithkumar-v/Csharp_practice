namespace Question1
{
    public class PersonInfo
    {
        public string Name {get;set;}
        public string FatherName{get;set;}
        public string MobileNumber {get;set;}
        public  string Gender{get;set;}

        public virtual void Display()
        {

        }
        public PersonInfo (string name,string fatherName,string mobileNumber, string gender){
            name = Name;
            FatherName = fatherName;
            MobileNumber = mobileNumber;
            Gender = gender;
            
        }
    }
}