﻿using System.Runtime.InteropServices.ComTypes;
using System;
namespace Question1;
class Program
{
    
   static void Display(int number)
    {
        System.Console.WriteLine("square value of given number "+ number*number);

    }
   static void Display(int number1,int number2)
    {
        System.Console.WriteLine("product of two number "+ number1*number2);
        
    }
  static   void Display(int number1,int number2,int number3)
    {
        System.Console.WriteLine("product of 3 numbers "+ number1*number2*number3);
    }

   static void Display(string name,int ID)

    {
        System.Console.WriteLine($"Name {name} ID {ID}");
    }
 static   void Display(int maths ,double physics,string name)
    {
        System.Console.WriteLine($"Name {name} MathsMark: {maths} PhysicsMark: {physics}");
    }
public static void Main(string[] args)
{
    Display(10);
    Display(10,20);
    Display(2,3,6);
    Display("ranjith",1);
    Display(100,90.0,"Kumar");

}

}