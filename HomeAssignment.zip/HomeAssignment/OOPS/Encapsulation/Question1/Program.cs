﻿using System;
using CalculatorApp;
namespace MathsLib;
class Program{
    public static void Main(string[] args)
    {
        Maths  math = new Maths();
        System.Console.WriteLine("Weight = " + math.CalculateWeight(75));
        CircleArea circle = new CircleArea();
        CylinderVolume cylinder = new CylinderVolume();
        cylinder.Radius = 4.5;
        cylinder.CalculateCircleArea();
        cylinder.Radius=4.5;
        cylinder.Height= 7.3;
        cylinder.CalculateVolume();
        System.Console.WriteLine($"Area of circle: {cylinder.Area}");
        System.Console.WriteLine($"volume of Cylinder:  {cylinder.Volume}");


    }
}