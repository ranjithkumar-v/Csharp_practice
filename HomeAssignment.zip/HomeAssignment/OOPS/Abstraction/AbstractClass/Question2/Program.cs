﻿using System;
namespace Question2;
class Program
{
    public static void Main(string[] args)
    {
        CSEDepartment cse = new CSEDepartment();
        cse.AuthorName = "Ranjith";
        cse.BookName = "rich dad poor dad ";
        cse.PublisherName ="Ranjith";
        cse.year = 2022;
        cse.DisplayInfo();
        EEEDepartment eee = new EEEDepartment();
         eee.AuthorName = "kumar";
        eee.BookName = "Atomic Habit";
        eee.PublisherName ="kumar";
        eee.year = 2022;
        eee.DisplayInfo();

    }
}