using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question2
{
    public abstract class Library
    {
        public static int s_serialNumber = 1000;
        public string SerialNumber { get; set; }
        public abstract string AuthorName { get; set; }
        public abstract string BookName  {get;set;}
        public abstract string PublisherName  {get;set;}
        public abstract int year { get; set; }

        public abstract void SetBookInfo();
        public abstract void DisplayInfo();
        





    }
}