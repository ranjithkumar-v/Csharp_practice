﻿using System;
namespace Question1;
class Program
{

 public static void Main(string[] args)
 {
    Cylinder cylinder = new Cylinder();
    cylinder.Radius = 5;
    cylinder.Height =4;
    Cubes cube = new Cubes();
    cube.a = 4;
    Console.WriteLine($"\nArea of cylinder = {cylinder.CalculateArea()}");
    Console.WriteLine($"\nVolume of Cylinder = {cylinder.CalculateVolume()}");
    Console.WriteLine($"\nArea of cube = {cube.CalculateArea()}");
    Console.WriteLine($"\n Volume of Cube = {cube.CalculateVolume()}");
    

 }   
}