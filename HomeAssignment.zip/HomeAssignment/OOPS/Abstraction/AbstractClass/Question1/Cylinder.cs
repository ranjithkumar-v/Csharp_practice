using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question1;
    public class Cylinder:Shape
    {
        public override double Area {get;set;}
        public override double Volume{get;set;}
        public override double CalculateArea()
        {
            return ( 2 * 3.14 * Radius );
        }
        public override double CalculateVolume()
        {
            return (3.14 * Radius * Height);

        }
    }