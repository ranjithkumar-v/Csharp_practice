using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question1
{
    public class Cubes:Shape
    {
        public override double Area{get;set;}
        public override double  Volume { get; set; }

        public override double CalculateArea()
        {
            return (6 * a * a);
        }
        public override double CalculateVolume()
        {
            return (a * a * a);
        }
    }
}