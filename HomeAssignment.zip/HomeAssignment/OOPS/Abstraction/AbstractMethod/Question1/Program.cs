﻿using System;
namespace Question1;
class Program
{
    public static void Main(string[] args)
    {
        
        MaruthiSwift swift = new MaruthiSwift();
        swift.CarType= CarType.HatchBatch;
        swift.EngineType = EngineType.Diesel;
        swift.NoOfSeats = 4;
        Console.WriteLine($"MaruthiSwift");
        swift.DisplayCarDetails();
        SuzukiCiaz suzuki =new SuzukiCiaz();
        suzuki.CarType = CarType.Sedan;
        suzuki.EngineType = EngineType.Petrol;
        suzuki.NoOfSeats = 5;
        Console.WriteLine($"\n\nSuzukiCars");
        suzuki.DisplayCarDetails();

    }
}