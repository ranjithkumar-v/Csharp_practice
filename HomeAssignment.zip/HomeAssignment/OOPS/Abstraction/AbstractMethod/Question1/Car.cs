using System.ComponentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question1
{
    public enum EngineType {Petrol,Diesel,Cng}
    public enum CarType {HatchBatch,Sedan,SUV}
    public  abstract class Car
    {
        public  int noOfWheels = 4;
        public int noOfDoors = 4;
        
        public int NoOfWheels { get{return noOfWheels;} }
        public int NoOfDoors {get{return noOfDoors;}}
        public EngineType  EngineType { get; set; }
        public int NoOfSeats { get; set; }
        public int Price { get; set; }
        public CarType CarType { get; set; }

        public  void ShowWheels()
        {
            Console.WriteLine($"no of Wheels {NoOfWheels} ");

        }
        public void ShowDoors()
        {
            Console.WriteLine($"no of Doors  {NoOfDoors}");
        }
        public abstract void DisplayCarDetails();
    }
}