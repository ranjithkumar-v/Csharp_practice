using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question1
{
    public class SuzukiCiaz:Car
    {
        public override void DisplayCarDetails()
        {
            Console.Write($"\nCarType {CarType} Engine Type {EngineType} NoofSeats {NoOfSeats}");
        }
    }
}