using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question2
{
    public class LadiesWear:Dress
    {
         public override DressType  DressType   { get; set; }
        public override string DressName { get; set; }
        public override int Price { get; set; }
        public override void DisplayInfo()
        {
            Console.Write($"DressType {DressType} DressName {DressName} Price {Price}");

        }
        public LadiesWear(DressType dressType,string dressName,int price)
        {
            DressType = dressType;
            DressName = dressName;
            Price = price;
        }
    }
}