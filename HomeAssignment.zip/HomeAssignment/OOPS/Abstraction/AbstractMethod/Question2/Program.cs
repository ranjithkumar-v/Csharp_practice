﻿using System;
namespace Question2;
class Program

{
    public static void Main(string[] args)
    {
        LadiesWear ladies = new LadiesWear(DressType.LadiesWear,"saree",500);
        Console.WriteLine($"Calling Display method of Ladies Class");
        ladies.DisplayInfo();
        MensWear mens = new MensWear(DressType.MensWear,"shirt",400);
        Console.WriteLine($"\nCalling Display method of Mens Class");

        mens.DisplayInfo();
    }
}