using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question2
{
    public enum DressType {MensWear,LadiesWear,}
    public abstract  class Dress
    {
        public abstract DressType  DressType   { get; set; }
        public abstract string DressName { get; set; }
        public abstract int Price { get; set; }

        public abstract void DisplayInfo();

    }
}