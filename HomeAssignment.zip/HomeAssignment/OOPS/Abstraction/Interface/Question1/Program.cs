﻿using System.Security.AccessControl;
using System;
namespace Question1;
class Program{
    public static void Main(string[] args)
    {
        Dog dog1 = new Dog();
        dog1.Name = "pomerian";
        dog1.Habitat ="Smart";
        dog1.EatingHabit = "eat 2 times a day";
        dog1.DisplayName();
        Dog dog2 = new Dog();
        dog2.Name ="Siberian Husky";
        dog2.Habitat="Cold";
        dog2.EatingHabit = "eat 3 times a day";
        dog2.DisplayName();
        Duck duck1 = new Duck();
        duck1.Name = "malaard";
        duck1.Habitat ="bobs their head up and down";
        duck1.EatingHabit="Meat eater";
        duck1.DisplayName();
        Duck duck2 = new Duck();
        duck2.Name="canavasBack";
        duck2.Habitat="sleepin";
        duck2.EatingHabit="eat 2 times a day";
        duck2.DisplayName();
    }
}