namespace Question2
{
    public class StudentInfo:IDisplayInfo
    {

    public int StudentID{get;set;}
    public string Name {get;set;}
    public string FatherName {get;set;}
    public string Mobile{get;set;}
        
        public void Display()
        {
            System.Console.WriteLine($"StudentID: {StudentID} Student Name {Name} FatherName: {FatherName} Mobile {Mobile}");

        }
    }
}