namespace Question2
{
    public class EmployeeInfo:IDisplayInfo
    {
        
     public int EmployeeID{get;set;}
    public string Name {get;set;}
    public string FatherName {get;set;}
    
    
        public void Display()
        {
            System.Console.WriteLine($"EmployeeID: {EmployeeID} Employee Name: {Name} FatherName: {FatherName}");

        }
}
}