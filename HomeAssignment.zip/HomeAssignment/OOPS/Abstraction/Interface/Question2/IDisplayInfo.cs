namespace Question2
{
    public interface IDisplayInfo
    {
         void Display();
    }
}