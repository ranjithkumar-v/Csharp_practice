﻿using System.Security.AccessControl;
using System;
namespace Question2;
class Program{
    public static void Main(string[] args)
    {
        StudentInfo student = new StudentInfo();
        student.Name = "Ranjith";
        student.StudentID=1000;
        student.FatherName="venkatesan";
        student.Mobile ="982983982";

        student.Display();
        EmployeeInfo employee = new EmployeeInfo();
        employee.EmployeeID=2000;
        employee.Name ="Ranjith";
        employee.FatherName ="venkatesan";
        employee.Display();
    }
}