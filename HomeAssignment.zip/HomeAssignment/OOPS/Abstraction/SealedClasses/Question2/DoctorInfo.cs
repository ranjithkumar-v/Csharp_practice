using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question2
{
    public class DoctorInfo:PatientInfo
    {
        public string DoctorID { get; set; }

        public string Name { get; set; }
        public string FatherName { get; set; }
        public void DisplayInfo()
        {
            Console.Write($"DoctorName {Name}");
        }
        
    }
}