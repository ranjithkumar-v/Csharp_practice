﻿using System;
    namespace Question2;
    class Program
{
    public static void Main(string[] args)
    {
        PatientInfo patient = new PatientInfo();
        patient.Name="Ram";
        patient.FatherName="Suresh";
        patient.AdmittedFor="corona";
        patient.BedNo =1;
        patient.NativePlace="chennai";
       patient.DisplayInfo();
       DoctorInfo doctor = new DoctorInfo();
       doctor.Name= "ramesh";
       doctor.DisplayInfo();
    }
}