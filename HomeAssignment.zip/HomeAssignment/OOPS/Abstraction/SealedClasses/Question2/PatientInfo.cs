using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question2
{
    public sealed class PatientInfo
    {
        public string PatientID { get; set; }
        public string Name {get;set;}
        public string FatherName { get; set; }
        public int BedNo { get; set; }
        public string NativePlace { get; set; }
        public string AdmittedFor { get; set; }

        public  void DisplayInfo()
        {
            Console.Write($"Name {Name} FatherName{FatherName} BedNo {BedNo} AdmittedFor {AdmittedFor}");

        }        
    }
}