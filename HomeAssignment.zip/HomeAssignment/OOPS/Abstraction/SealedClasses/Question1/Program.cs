﻿using System;
namespace Question1;
class Program{
    public static void Main(string[] args)
    {
        EmployeeInfo employee = new EmployeeInfo();
        employee.UpdateInfo(20);
        
    }
}