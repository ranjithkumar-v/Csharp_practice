using System.Security.Cryptography.X509Certificates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question1
{
    public sealed  class EmployeeInfo
    {
        public string UserID { get; set; }
        public string Password { get; set; }

        public static int s_keyInfo = 100;
        public int KeyInfo {get;set;}
        public void UpdateInfo(int number)
        {
            KeyInfo = number;
        }
        public void DisplayInfo()
        {
               System.Console.WriteLine(); 
        }
    }
}