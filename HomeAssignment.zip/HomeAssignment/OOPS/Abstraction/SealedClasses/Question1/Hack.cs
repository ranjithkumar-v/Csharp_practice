using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question1
{
    public class Hack:EmployeeInfo
    {
        public string StoreUserID { get; set; }
        public string  StorePassword { get; set; }
        public static void ShowKeyInfo()
        {

        }
         public static void GetUserInfo()
        {

        }
         public static void ShowUserInfo()
        {

        }
        
    }
}