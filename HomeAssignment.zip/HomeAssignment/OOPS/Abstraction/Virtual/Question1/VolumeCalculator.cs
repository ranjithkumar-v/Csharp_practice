using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question1;
    public class VolumeCalculator:AreaCalculator
    {
        public double Height { get; set; }

        public override void Calculate(double r)
        {
            Console.Write($"volume {3.14 *r*r*Height}");
            Console.Write($"text");
        }
    }
