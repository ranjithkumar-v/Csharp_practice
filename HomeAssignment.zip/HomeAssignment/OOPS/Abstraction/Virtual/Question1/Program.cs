﻿using System;
namespace Question1;
class Program
{
    public static void Main(string[] args)
    {
        AreaCalculator  area = new AreaCalculator();
        area.Calculate(5);
        VolumeCalculator volume = new VolumeCalculator();
        volume.Height= 6;
        volume.Calculate(4);

    }
}