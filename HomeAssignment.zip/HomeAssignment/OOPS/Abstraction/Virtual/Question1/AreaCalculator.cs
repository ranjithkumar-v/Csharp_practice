using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question1;
    public class AreaCalculator
    {
        public double Radius { get; set; }
        
        public virtual void Calculate(double r)
        {
            Console.Write($" Area {3.14 * r * r}");
        }
     
    }