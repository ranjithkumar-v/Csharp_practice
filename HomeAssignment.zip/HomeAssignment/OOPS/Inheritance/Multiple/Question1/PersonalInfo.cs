using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question1
{
    public enum MaritalStatus {Married,single}
    public class PersonalInfo:IShowData
    {
        public  string Name { get; set; }
        public String Gender { get; set; }
        public DateTime  DOB { get; set; }
        public string Phone { get; set; }
        public MaritalStatus  MaritalStatus { get; set; }

        public static void IShowData()
        {

        }
    }
}