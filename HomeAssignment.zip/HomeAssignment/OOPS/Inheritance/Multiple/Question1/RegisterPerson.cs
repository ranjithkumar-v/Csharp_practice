using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question1
{
    public class RegisterPerson:PersonalInfo,IShowData,IFamilyInfo

    {
        private static int s_registerNumber = 1000;
        public int RegistrationNumber { get{return s_registerNumber;}}

        public DateTime DateOfRegistration;
        public string FatherName {get;set;}
         public string MotherName { get; set; }
        public string   HouseAddress {get;set;}
        public int NoOfSiblings{get;set;}

       public RegisterPerson(DateTime dob,string fatherName,string motherName,string homeAddress,int noOfSiblings,string name,string gender,DateTime dob)

        public static void ShowInfo()
        {

        }
    }
}