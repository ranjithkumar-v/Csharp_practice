﻿using System;
namespace Question1;
class Program
{
    public static void Main(string[] args)
    {
        
    }
}