using System;
namespace Question1
{
    public class StudentInfo:PersonalInfo
    {
    public int  RegisterID {get;set;}
    public string Standard {get;set;}

    public string Branch{get;set;}
    public int AcadamicYear{get;set;}

    public StudentInfo(int registerID,string standard,string branch,int acadamicYear,string name,string fatherName,string phone,string mail,DateTime dob,string gender):base(name,fatherName,phone, mail,dob, gender)
    {
        RegisterID = registerID;
        Standard = standard;
        Branch = branch;
        AcadamicYear = acadamicYear;
    }
    public  void ShowStudentInfo()
    {
        System.Console.WriteLine($"Student RegisterID {RegisterID} Student Name: {Name} FatherName {FatherName} Gender {Gender} phoneNUmber {Phone} DOB {DOB.ToShortDateString()} Standard {Standard} Branch {Branch} Acadamic year {AcadamicYear} ");
    }

    }
}