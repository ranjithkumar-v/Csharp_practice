using System;
namespace Question2;

    public class AccountInfo:PersonalInfo
    {
        public int   AccountNumber{get;set;}
        public string BranchName{get;set;}
        public int IFSCCode {get;set;}
        public double Balance{get;set;}

        public AccountInfo(int accountNumber,string branchName,int ifscCode,double balance,string name,string fatherName,string phone,string mail,DateTime dob,string gender):base( name, fatherName, phone,mail,dob, gender)
        {
            AccountNumber = accountNumber;
            BranchName = branchName;
            IFSCCode = ifscCode;
            Balance = balance;


        }
        public void ShowAccountInfo()
        {
            System.Console.WriteLine($"Name {Name} FatherName {FatherName} accountNumber: {AccountNumber} BranchName {BranchName} IFSCCODE: {IFSCCode}   ");
        }
       
        public void ShowBalance()
        {
            System.Console.WriteLine($"Balance: {Balance}");
        }

    }

