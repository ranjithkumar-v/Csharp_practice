﻿using System.Security.AccessControl;
using System;
namespace Question2;
class Program{
    public static void Main(string[] args)
    {
         PersonalInfo person = new PersonalInfo("Ranjith","Venkatesan","1234555","ranjith@gmail.com",new DateTime(2022,05,12),"male");
        AccountInfo account = new AccountInfo(1001,"chennai",12345,500,"Ranjith","Venkatesan","1234555","ranjith@gmail.com",new DateTime(2022,05,12),"male");
    }
}