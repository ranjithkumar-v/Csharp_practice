﻿using System;
namespace Question2;
class Program
{
    public static void Main(string[] args)
    {
        
    }
}