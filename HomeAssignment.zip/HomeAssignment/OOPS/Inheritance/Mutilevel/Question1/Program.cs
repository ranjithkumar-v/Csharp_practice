﻿using System;
namespace Question1;
class Program{
    public static void Main(string[] args)
    {
        PersonalInfo person = new PersonalInfo("Ranjith","Venkatesan","1234555","ranjith@gmail.com",new DateTime(2022,05,12),"male");
        StudentInfo student = new StudentInfo(2001,"I","CSE",2022,"Ranjith","Venkatesan","1234555","ranjith@gmail.com",new DateTime(2022,05,12),"male");
        HSCDetails studentHSC = new HSCDetails(1000,79,89,90,"Ranjith","Venkatesan","1234555","ranjith@gmail.com",new DateTime(2022,05,12),"male");
    }
}