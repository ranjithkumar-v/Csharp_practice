using System;
namespace Question1
{
    public class HSCDetails:StudentInfo
    {
        public int HSCMarkSheetNumber {get;set;}
        public int Physics {get;set;}
        public int Chemistry{get;set;}
        public int Maths{get;set;}
        public int Total {get;set;}

        public int PercentageMarks{get;set;}
        public HSCDetails(int hscMarkSheetNumber,int physics,int chemistry,int maths,string name,string fatherName,string phone,string mail,DateTime dob,string gender):base(name,fatherName,phone,mail,dob,gender)
        {

            HSCMarkSheetNumber =hscMarkSheetNumber;
            Physics = physics;
            Chemistry = chemistry;
            Maths = maths;
        }
        public void Calculate(){
            System.Console.WriteLine();
        }
    }
}