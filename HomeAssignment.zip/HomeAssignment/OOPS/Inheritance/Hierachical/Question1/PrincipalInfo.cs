using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question1
{
    public class PrincipalInfo
    {
        private static int s_principalID = 2000;
        public string PrincipalID { get; set; }

        public string Qualification { get; set; }
        public int YearsOfExperience{get;set;}
        public DateTime DOB{get;set;}
        public PrincipalInfo(string name,string fatherName,string phoneNumber,string mailID,DateTime dob, string gender):base(name,fatherName,phoneNumber,mailID,dob,gender){


        }
        public void ShowDetails()
        {
            Console.WriteLine($"\nprincipal ID {PrincipalID}");
            console.WriteLine($"example");
        }
    
    }
}