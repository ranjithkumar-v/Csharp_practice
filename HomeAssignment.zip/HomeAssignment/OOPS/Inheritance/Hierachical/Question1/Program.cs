﻿using System;
namespace Question1;
class Program
{
}