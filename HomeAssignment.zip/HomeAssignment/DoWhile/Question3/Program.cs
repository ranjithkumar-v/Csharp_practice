﻿using System;
namespace Question3;
    class Program{
        public static void Main(string[] args)
        {       
                System.Console.WriteLine(" Enter number of terms to  display");
                int num = Convert.ToInt32(Console.ReadLine());
                int n1= 0,n2= 1;
                int n3;
                
              System.Console.Write(n1 + " ");
            System.Console.Write(n2 + " ");
            do{
               
                 n3 =n1+n2;
                 System.Console.Write(n3+" ");
                 n1 =n2;
                 n2=n3;
                 num--;
            }while (num > 2);
                
            
        }
    }
