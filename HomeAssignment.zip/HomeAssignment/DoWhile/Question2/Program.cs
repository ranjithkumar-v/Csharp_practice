﻿using System;
namespace Question2;
    class Program{
        public static void Main(string[] args)
        {
            int num,sum =0;
         do{
            System.Console.Write("Enter a number ");
            num =Convert.ToInt32(Console.ReadLine());
            sum += num;

         }while(num >= 0);
         System.Console.WriteLine("sum = " + sum);
        }
    }