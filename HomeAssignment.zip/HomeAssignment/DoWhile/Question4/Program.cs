﻿using System;
namespace Question4;
    class Program{
        public static void Main(string[] args)
        {
            int num;
            bool check;
        do{
            System.Console.Write("Enter a number");
            check = int.TryParse(Console.ReadLine(),out num);    
            

        }while(  check != true && num <=10 && num >=0 );
     System.Console.WriteLine("output "+num);
        }
        }