﻿using System;
namespace SwitchAssignment;
class Program {
    public static void Main(string[] args)
    {   System.Console.Write("Enter firstnum: ");
        int firstNum = Convert.ToInt32(Console.ReadLine()) ;
        System.Console.Write("Enter secondnum: ");
        int secondNum = Convert.ToInt32(Console.ReadLine()) ;
        
        System.Console.WriteLine("Select any operation \n 1. addition  \n 2. substraction \n 3. multiplication \n 4. division \n 5. modulo division");
        System.Console.WriteLine("Enter the  arithmetic  symbol which is needed");
        char option = Convert.ToChar(Console.ReadLine());
        switch(option){

            case '+':
                    System.Console.WriteLine("addition: " + (firstNum + secondNum)) ;
                    break;
            case '-':
                System.Console.WriteLine("substraction: " + (firstNum - secondNum));
                break;
            case '*':
                System.Console.WriteLine("Multiplication: " + firstNum * secondNum);
                break;
            case '/':
                System.Console.WriteLine("Division: " + firstNum / secondNum );
                break;
            case '%':
                System.Console.WriteLine("Modulo division:  " + firstNum % secondNum);
                break;

            default:
                System.Console.WriteLine("Invalid operation");
                break;
                
        }
        
    }
}
