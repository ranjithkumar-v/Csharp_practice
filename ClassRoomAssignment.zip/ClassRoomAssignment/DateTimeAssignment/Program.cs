﻿using System;
namespace DateTimeAssignment;
    class Program{
        public static void Main(string[] args)
        {
            DateTime dob = new DateTime (2021,8,10,10,40,32);
            System.Console.WriteLine("Year: "+ dob.Year);
            System.Console.WriteLine("Month: "+ dob.Month);
            System.Console.WriteLine("Day: "+ dob.Day);
            System.Console.WriteLine("Hour: "+ dob.Hour);
            System.Console.WriteLine("mintue: "+ dob.Minute);
            System.Console.WriteLine("Second: "+ dob.Second);

            string dataTimeString = dob.ToString();
            System.Console.WriteLine(dataTimeString);
            char [] separator = {'/',' ',':' };
            string [] ch = dataTimeString.Split(separator);
            for(int i =ch.Length-1;i>=0;i--)
            {
             System.Console.Write(ch[i]+" ");
            }
           System.Console.WriteLine("\n Enter DateTime yyyy/MM/dd hh:mm:ss tt");
           DateTime userDate = DateTime.ParseExact(Console.ReadLine(),"yyyy/MM/dd hh:mm:ss tt",null);
            System.Console.WriteLine("Year: "+ userDate.Year);
            System.Console.WriteLine("Month: "+ userDate.Month);
            System.Console.WriteLine("Day: "+userDate.Day);

}
}
