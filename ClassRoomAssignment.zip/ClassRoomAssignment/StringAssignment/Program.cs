﻿using System.Reflection.Emit;
using System;
namespace StringAssignment;
    class Program{
        public static void Main(string[] args)
        {

            Console.Write("enter the string ");
            string str = Console.ReadLine();
            System.Console.Write("string to be searched ");
            string subStr = Console.ReadLine();
           string [] splitStr =  str.Split(subStr);
           System.Console.Write("occurence ");
           System.Console.WriteLine(splitStr.Length -1);

        }

    }