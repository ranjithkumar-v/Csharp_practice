﻿
using System;
namespace TypeConversion{
    class Program{
        public static void Main(string[] args)
        {
            
        Console.Write("Enter your name ");
        string name = Console.ReadLine();
        
        Console.Write("Enter age ");
        int age = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter marks of subject1 ");
        int subject1 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter marks of subject2 ");
        int subject2 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter marks of subject2 ");
        int subject3 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter Grade ");
        string grade = Console.ReadLine();
        Console.Write("Enter mobile number ");
        long mobileNum =  Convert.ToInt64(Console.ReadLine());
        Console.Write("Enter emailId ");
        string email = Console.ReadLine();

        //output
                        Console.WriteLine("Trainee details ");
                        Console.WriteLine("Name " + name);
                        Console.WriteLine("age " + age);
                        Console.WriteLine("Mobile " + mobileNum);
                        Console.WriteLine("Mark1 "+ subject1);
                        Console.WriteLine("Mark2 "+ subject2);
                        Console.WriteLine("Mark3 "+ subject3);
                        double total = subject1 + subject2 + subject3;
                        Console.WriteLine("Total " + total);
                        double average = total / 3 ;
                        Console.WriteLine("Average: " + Math.Round(average,2));
                        Console.WriteLine("Grade  "+ grade);
                        Console.WriteLine("Mail Id " + email);












        }
    }
}
