﻿
using System;
namespace IfStatement{
    class Program{
        public static void Main(string[] args)
        {   Console.Write("Input ");
            int mark = Convert.ToInt32(Console.ReadLine());
            if( mark >= 1 && mark <=100)
            {
                if( mark >80 ){
                    Console.WriteLine("Output: Grade A ");

                }
                if(mark > 60 && mark <= 80){
                    Console.WriteLine("Output: Grade B");

                }
                if(mark >35 && mark <= 60 )
                {
                    Console.WriteLine("Output: Grade C");

                }
                if(mark <= 35){
                    Console.WriteLine("Output: Grade D");

                }
            }
            else{
                    Console.WriteLine("Output: Invalid input ");

            }
        }
    }
}