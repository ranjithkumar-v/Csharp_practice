﻿using System;
namespace WhileAssignment;
 class Program{
    public static void Main(string[] args)
    {
        int i = 1;
        while(i<25)
        {
            if(i % 2 == 0){
                System.Console.WriteLine(i);
            }
            i++;
        }
        System.Console.Write("Enter a number: ");
        bool flag;
        int num ;
        string n = Console.ReadLine();
        flag = int.TryParse(n, out num);
        while(!flag){

            System.Console.WriteLine("Invalid input format Please enter the input in number format");
            n = Console.ReadLine();
           flag = int.TryParse(n, out num);
           }
        System.Console.WriteLine("the num is valid " + num);
    }
 }
