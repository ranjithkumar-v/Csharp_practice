﻿
using System;
namespace ArrayAssignment;
    class Program{
        public static void Main(string[] args)
        {

          string[] name = new string [5];
          System.Console.WriteLine("Enter name");
          for(int i=0;i<5;i++)
          {
            name[i] =Console.ReadLine();
            
          }
          System.Console.WriteLine("Entered names ");
           for(int i=0;i<5;i++)
           {
            
            System.Console.WriteLine(name[i]);
            
          }
          System.Console.WriteLine("searching using for loop");
          System.Console.WriteLine("enter name for searching");
          string serachNameFor = Console.ReadLine();
          int found =0,nameIndex=0;
          for(int i=0;i<5;i++)
          {
            if(name [i] == serachNameFor){
                found =1;
                nameIndex = i;

            }
          }
             if(found ==1){
                System.Console.WriteLine("The name is present in a array");
                System.Console.WriteLine("index value of  "+ serachNameFor + " " + nameIndex);
             }
           else{
            System.Console.WriteLine("the name is not present ");
             }
          
        
             
          System.Console.WriteLine("searching using forEach loop");
          System.Console.WriteLine("enter name for searching");
          string  searchNameForEach = Console.ReadLine();
          int foreachFound =0;
          foreach(string nam in name )
          {
                if(nam == searchNameForEach){
                    foreachFound =1;
                }
          }
                if(foreachFound ==1){
                    System.Console.WriteLine("the name is present in the array");

                }
                else{
                    System.Console.WriteLine("the name is not present in a array");
                }

        }
        }