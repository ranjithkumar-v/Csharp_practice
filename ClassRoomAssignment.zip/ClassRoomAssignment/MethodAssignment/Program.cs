﻿using System;
namespace MethodAssignment;
    class Program{
        public static void Main(string[] args)
        {
            string status="";
            do{
                System.Console.Write( "1. Addition \n 2. Subtraction \n 3. Multiplication \n 4. Division \n");
                System.Console.WriteLine("enter choice");
            int choice = Convert.ToInt32(Console.ReadLine());
            System.Console.WriteLine("enter the two number");
            int num1 = Convert.ToInt32(Console.ReadLine());
            int num2 = Convert.ToInt32(Console.ReadLine());
            
             switch(choice){
                case 1:
                   int  addNum = Add(num1,num2);
                    System.Console.WriteLine("Addition: "+ addNum);
                    break;
                case 2:
                    int subNum = Sub(num1,num2);
                    System.Console.WriteLine("Substraction: "+subNum);
                    break;                    
                case 3:
                    int mulAdd = Mul(num1,num2);
                    System.Console.WriteLine( "multiplication: "+ mulAdd);
                    break;         
          
                case 4:
                    int divNum = Division(num1,num2);
                    System.Console.WriteLine("Division: "+ divNum);
                    break;    
                default:
                System.Console.WriteLine("enter valid input");
                    break;   
             }   
          
          int Add(int num1,int num2){
            
            return num1 +num2;
          }
          int Sub(int num1,int num2){
            return num1 - num2;
          }
          int Mul(int num1,int num2){
            return num1 * num2;
          }
          int Division(int num1,int num2){
            return (num1/num2);
            }
            Console.WriteLine("do you want to continue ");
            status =Console.ReadLine().ToLower();
        
             }while(status=="yes");
        }

        }
    
