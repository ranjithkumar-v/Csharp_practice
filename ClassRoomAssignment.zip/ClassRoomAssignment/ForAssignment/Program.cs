﻿using System;
namespace ForAssignment;
    class Program{
        public static void Main(string[] args)
        {
            for(int i =1;i<=25;i++){
                if(i%2 == 0){
                    System.Console.WriteLine(i);
                }
            }
        System.Console.Write("enter inital value: ");
        int initalValue = Convert.ToInt32(Console.ReadLine());
        System.Console.Write("enter final value: ");
        int finalValue = Convert.ToInt32(Console.ReadLine());
        int output =0;
        for(int j =initalValue;j<=finalValue;j++){
            output +=  j*j;
        }
        System.Console.WriteLine("sum of the square of the number = " + output);

        }
    }